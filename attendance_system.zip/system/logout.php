<?php 
session_start();
$_SESSION["userid"] = ''; // Clearing the session variable
session_destroy(); // Destroying the session
header("Location: index.php"); // Redirecting to index.php
exit; // Terminate script execution after redirection
?>
